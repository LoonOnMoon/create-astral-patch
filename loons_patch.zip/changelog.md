# Loon's patch for Create: Astral

## Version: 1.0.1

### Added the following mods

- AmbientSounds_FABRIC_v5.0.16_mc1.18.2.jar
- collective-1.18.2-7.7.jar
- CosmeticArmor-1.18.2-1.3.1.jar
- CreativeCore_FABRIC_v2.6.12_mc1.18.2.jar
- DetailArmorBar-2.6.2+1.18-fabric.jar
- doubledoors-1.18.2-5.1.jar
- durabilitytooltip-1.1.5-fabric-mc1.18.jar
- dynamiccrosshair-5.0+1.18.2-fabric.jar
- dynamiccrosshair-compat-1.4+1.18.2.jar
- EquipmentCompare-1.18.2-fabric-1.2.12.jar
- held-item-info-1.4.2+1.18.jar
- Highlighter-1.18-fabric-1.1.2.jar
- LeavesBeGone-v3.0.0-1.18.2-Fabric.jar
- LegendaryTooltips-1.18.2-fabric-1.3.3.jar
- MapFrontiers-1.18.2-2.5.1-fabric.jar
- notenoughanimations-fabric-1.7.1-mc1.18.2.jar
- Prism-1.18.2-fabric-1.0.3.jar
- skinlayers3d-fabric-1.6.2-mc1.18.2.jar
- status-effect-bars-1.0.1.jar
- supermartijn642configlib-1.1.8a-fabric-mc1.18.jar
- trashslot-fabric-1.18.2-11.0.3.jar

### Updated mods

- PuzzlesLib-v3.5.2-1.18.2-Fabric.jar

### Other changes

- Added default keybindings by replacing options.txt (I'll try not to do this often)
- Added JourneyMap default config
- Added default shader options

## Version: 1.0.0

### Added the following mods

- BiomeParticleWeather-v4.0.21-1.18.2-1.18.2-Fabric.jar
- creeperoverhaul-1.3.1-fabric.jar
- expandeddelight-0.1.9.1.jar
- farmers-delight-fabric-1.18.2-1.2.5.jar
- farmersknives-1.3.1.jar
- fish_of_thieves-mc1.18.2-v1.1.1-fabric.jar
- PresenceFootsteps-1.5.1.jar
- soundphysics-fabric-1.18.2-1.0.6.jar
- wraith-waystones-3.0.0+mc1.18.2.jar
